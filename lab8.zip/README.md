# Tina Rickard, William Eggert
# CSC 365-03
# Lab 8

To run, change serversettings to use your username and password
also change the url to have your username at the end of it instead of mine

to run the program
type

java -cp .:mysql-connector-java-5.1.44-bin.jar InnReservations

after compiling


-- NOTES: --

For the purposes of this assignment:

A day is counted as "unavailable" if it overlaps with a check in date, not
necessarily a check out date.

For the Owner (OR) problems:
Only reservations that end in the year 2010 count toward revenue and day totals
for 2010 (see OR-2).

*Note to self: This program takes several seconds to compile

